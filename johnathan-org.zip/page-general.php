<article class="h-entry {{post_class}} h-entry" itemscope itemtype="http://schema.org/BlogPosting">
  <h1 class="p-name" itemprop="headline"><a href="#"><?php the_title(); ?></a></h1>

  <div class="e-content">
  <?php the_content(); ?>
  </div>
</article>
<br /><br />

